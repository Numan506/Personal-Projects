from django.contrib import admin
from .models import *

# Register your models here.
admin.site.register(Burger)
admin.site.register(Biriyani)
admin.site.register(Pizza)
admin.site.register(Pasta)
admin.site.register(Sandwich)