from django.apps import AppConfig


class RestaurantappConfig(AppConfig):
    name = 'restaurantapp'
