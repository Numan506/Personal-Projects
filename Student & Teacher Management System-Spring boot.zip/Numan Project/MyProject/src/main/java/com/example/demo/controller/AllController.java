package com.example.demo.controller;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;


import com.example.demo.User;
import com.example.demo.UserRepository;
import com.example.demo.model.AdminPage;
import com.example.demo.model.Student;
import com.example.demo.model.Teacher;
import com.example.demo.repository.TeacherRepository;

import com.example.demo.service.StudentService;
import com.example.demo.service.TeacherService;


@Controller
public class AllController {
	
	@Autowired
	private StudentService studentService;
	
	@Autowired
	private TeacherService teacherService;
	
	@Autowired
	private UserRepository repo;
	
   // @Autowired(required=true)
	
	//public UserRepository repos;
	

	
	
	@GetMapping("")
	public String viewMainPage() {
		return"home";
	}
	
	@GetMapping("/about")
	public String viewAboutPage() {
		return"about";
	}


	@GetMapping("/index")
	public String viewHomePage() {
		return"index";
	}
	
	
	
	@GetMapping("/register")
	public String showSignUpFrom(Model model) {
		model.addAttribute("user", new User());
		
		return "signup_from";
	}
	
	@PostMapping("/process_register")
	public String processRegistration(User user) {
		BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
		String encodedPassword = encoder.encode(user.getPassword());
		user.setPassword(encodedPassword);
		repo.save(user);
		return "register_success";
	}
	
	@GetMapping("/list_users")
	public String viewUserList(Model model) {
		
		List<User>listUsers = repo.findAll();
		model.addAttribute("listUsers",listUsers);
		return "users";
	}
	
	@GetMapping("/listusersAdmin")
	public String viewUserListAdmin(Model model) {
		
		List<User>listUsers = repo.findAll();
		model.addAttribute("listUsers",listUsers);
		return "users_admin";
	}
	

	@GetMapping("/courseList")
	public String studentList(Model model) {
	
		model.addAttribute("listCourse",studentService.getAllStudents());
	    return "course_list";
	}
	
	@GetMapping("/courseListAdmin")
	public String studentListAdmin(Model model) {
	
		model.addAttribute("listCourse",studentService.getAllStudents());
	    return "course_list_admin";
	}
	
	@GetMapping("/newCourseForm")
	public String newStudentForm(Model model) {
		//create Student form data
		model.addAttribute("course", new Student());
		return "new_course";
	}
	
	@PostMapping("/saveCourse")
	public String saveStudent(@ModelAttribute("student") Student student) {
		//save student database
		studentService.saveCourse(student);
		return "redirect:/courseList";
	}
	
	@GetMapping("/CourseFormUpdate/{id}")
	public String showStudentFormUpdate(@PathVariable(value="id") long id,Model model) {
		//get Student
		Student student = studentService.getCourseId(id);
		
		//set Student
		model.addAttribute("course", student);
		return "update_course";
	}
	
	@PostMapping("/saveCourseAdmin")
	public String saveStudentAdmin(@ModelAttribute("student") Student student) {
		//save student database
		studentService.saveCourse(student);
		return "redirect:/courseListAdmin";
	}
	
	@GetMapping("/CourseFormUpdateAdmin/{id}")
	public String showStudentFormUpdateAdmin(@PathVariable(value="id") long id,Model model) {
		//get Student
		Student student = studentService.getCourseId(id);
		
		//set Student
		model.addAttribute("course", student);
		return "update_course_admin";
	}
	
	@GetMapping("/deleteStudent/{id}")
	public String deleteStudent(@PathVariable(value="id") long id) {
		//delete Student
		
		this.studentService.deleteById(id);
		return "redirect:/courseList";
	}
	
	@GetMapping("/deleteStudentAdmin/{id}")
	public String deleteStudentAdmin(@PathVariable(value="id") long id) {
		//delete Student
		
		this.studentService.deleteById(id);
		return "redirect:/courseListAdmin";
	}
	
	@GetMapping("/teacherList")
	public String teacherList(Model model) {
	
		model.addAttribute("listTeachers",teacherService.getAllTeachers());
	    return "teacher_list";
	}
	
//	@GetMapping("/teacherListAdmin")
//	public String teacherListAdmin(Model model) {
//	
//		model.addAttribute("listTeachers",teacherService.getAllTeachers());
//	    return "teacher_list_admin";
//	}
	
//	@GetMapping("/teacherListAdmin")
//	public String teacherListAd(Model model) {
//	
//		model.addAttribute("listTeachers",teacherService.getAllTeachers());
//	    return "teacher_list_admin";
//	}
	
	@GetMapping("/teacherListAdmin")
	public String teacherListAdmin(Model model) {
	
		model.addAttribute("listTeachers",teacherService.getAllTeachers());
	    return "teacher_list_admin";
	}
	
	@GetMapping("/newTeacherForm")
	public String newTeacherForm(Model model) {
		//create Teacher form data
		model.addAttribute("teacher", new Teacher());
		return "new_teacher";
	}
	
	@GetMapping("/newTeacherFormAdmin")
	public String newTeacherFormAdmin(Model model) {
		//create Teacher form data
		model.addAttribute("teacher", new Teacher());
		return "new_teacher_admin";
	}
	
	@PostMapping("/saveTeacher")
	public String saveTeacher(@ModelAttribute("teacher") Teacher teacher) {
		//save Teacher database
		teacherService.saveTeacher(teacher);
		return "redirect:/teacherList";
	}
	
//	@PostMapping("/saveTeacherAdmin")
//	public String saveTeacherAdmin(@ModelAttribute("teacher") Teacher teacher) {
//		//save Teacher database
//		teacherService.saveTeacher(teacher);
//		return "redirect:/teacherList";
//	}
	
	
	@PostMapping("/saveTeacherAdmin")
	public String saveTeacherAdmin(@ModelAttribute("teacher") Teacher teacher) {
		//save Teacher database
		teacherService.saveTeacher(teacher);
		return "redirect:/teacherListAdmin";
	}
	
	@GetMapping("/TeacherFormUpdate/{id}")
	public String showTeacherFormUpdate(@PathVariable(value="id") long id,Model model) {
		//get Teacher
		Teacher teacher = teacherService.getTeacherId(id);
		
		//set Teacher
		model.addAttribute("teacher", teacher);
		return "update_Teacher";
	}
	
	@GetMapping("/TeacherFormUpdateAdmin/{id}")
	public String showTeacherFormUpdateAdmin(@PathVariable(value="id") long id,Model model) {
		//get Teacher
		Teacher teacher = teacherService.getTeacherId(id);
		
		//set Teacher
		model.addAttribute("teacher", teacher);
		return "update_Teacher_admin";
	}
	
	
	@GetMapping("/deleteTeacher/{id}")
	public String deleteTeacher(@PathVariable(value="id") long id) {
		//delete Teacher
		
		this.teacherService.deleteBYId(id);
		return "redirect:/courseList";
	}
	
	@GetMapping("/deleteTeacherAdmin/{id}")
	public String deleteTeacherAdmin(@PathVariable(value="id") long id) {
		//delete Teacher
		
		this.teacherService.deleteBYId(id);
		return "redirect:/teacherListAdmin";
	}
	

    @GetMapping("/admin")
    
    public String adminLogin(Model model) {
    	
    	AdminPage adminPage = new AdminPage();
    	model.addAttribute("adminPage",adminPage);

    	return"admin_login";
    }


    @PostMapping("/adminLogin")
    
    public String adminLogin(@ModelAttribute("adminPage") AdminPage adminPage) {
    	
    	String userName = adminPage.getUserName();
    	if(adminPage.getPassword().equals("123456") && userName.equals("numan")) {
    		return"home2";
    	}else {
    		return "error";
    	}
    	

    	
    }


	
}
