package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Student;
import com.example.demo.repository.StudentRepository;

import net.bytebuddy.dynamic.DynamicType.Builder.FieldDefinition.Optional;

@Service
public class StudentServiceImpl implements StudentService{

	@Autowired
	private StudentRepository studentRepository;
	
	@Override
	public List<Student> getAllStudents() {
		
		return studentRepository.findAll();
	}

	@Override
	public void saveCourse(Student student) {
		this.studentRepository.save(student);
		
	}

	@Override
	public Student getCourseId(long id) {
		java.util.Optional<Student>optional = studentRepository.findById(id);
				Student student = null;
				if(optional.isPresent()) {
					student= optional.get();
				}else {
					throw new RuntimeException("not found"+id);
				}
		return student;
	}

	@Override
	public void deleteById(long id) {
		this.studentRepository.deleteById(id);
		
	}

}
