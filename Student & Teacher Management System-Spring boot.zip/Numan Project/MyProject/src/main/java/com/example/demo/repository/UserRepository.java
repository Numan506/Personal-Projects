package com.example.demo.repository;





public interface UserRepository  {

}
