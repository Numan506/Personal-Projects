package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Student;
import com.example.demo.model.Teacher;
import com.example.demo.repository.TeacherRepository;

@Service
public class TeacherServiceImpl implements TeacherService  {

	@Autowired
	private TeacherRepository teacherRepository;

	
		
	@Override
	public List<Teacher>getAllTeachers(){
			
			return teacherRepository.findAll();
		}



	@Override
	public void saveTeacher(Teacher teacher) {
		
		this.teacherRepository.save(teacher);
	}



	@Override
	public Teacher getTeacherId(long id) {
		
		java.util.Optional<Teacher>optional = teacherRepository.findById(id);
		Teacher teacher = null;
		if(optional.isPresent()) {
			teacher= optional.get();
		}else {
			throw new RuntimeException("not found"+id);
		}
           return teacher;
		
	}



	@Override
	public void deleteBYId(long id) {
		this.teacherRepository.deleteById(id);
		
	}
	}
	
	

